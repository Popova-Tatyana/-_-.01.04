/** Задание к зачету. Попова Т.А,, КМПО РАНХиГС
Вариант 21.
В базе данных кадрового агентства хранятся сведения о вакансиях, включая следующие требования: образование, профессию, уровень владения компьютером.
Структура входного файла in.txt (Дата опубликования Вакансия Оклад Актуальность)
15.05 Токарь 40000 д
16.05 Программист 50000 н
16.05 Аналитик 80000 д
…
Сформировать список актуальных вакансий, упорядочив по алфавиту.
Структура выходного файла out.txt
Аналитик 80000
Токарь 40000
*/
/** Решение. Попова Т.А., уровень A */
/** Начало решения 19.03.2024, 08:30
Окончание решения 19.03.2024, 09:25
Общее время 00:55 */

#include <stdio.h>
#include <math.h>
#include <locale.h>
#include <string.h>

#define AGENCY_SIZE 1000

typedef struct {
	char date[20];
	char vacancy[20];
	int oklad;
	char actual[20];
} Vacancy;

void print_out(Vacancy v[], int n) {
	FILE *out = fopen("out.txt", "w");
	for (int i = 0; i < n; i++) {
        fprintf(out, "%s %d\n", v[i].vacancy, v[i].oklad);
	}
	fclose(out);
}

int main(void) {
    char *locale = setlocale(LC_ALL, "");
	Vacancy v[AGENCY_SIZE];

	FILE *in = fopen("in.txt", "r");
	int n = 0;
	Vacancy vac;

	while (fscanf(in, "%s %s %d %s", vac.date, vac.vacancy, &vac.oklad, vac.actual) == 4)
	{
        if (strcmp(vac.actual, "д") == 0) {
            v[n++] = vac;
        }
    }
	fclose(in);

    /** Сортируем выбором */
	for (int i = 0; i < n-1; i++) {
        int imin = i;
        for (int j = i+1; j < n; j++) {
            if (strcmp(v[j].vacancy, v[imin].vacancy) < 0) {
                imin = j;
            }
        }
        if (imin != i) {
            Vacancy t = v[imin];
            v[imin] = v[i];
            v[i] = t;
        }
	}
	
    /** Проверочная печать */
	for (int i = 0; i < n; i++) {
        printf("%s %d\n", v[i].vacancy, v[i].oklad);
	}

    /** Выводим в файл */
	print_out(v, n);
	return 0;
}
